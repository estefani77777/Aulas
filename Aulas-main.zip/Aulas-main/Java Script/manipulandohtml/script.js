// Mudar a cor da tela de fundo 
window.document.body.style.background = 'black'

//mudar cor da letra
window.document.body.style.color = 'white'

//criando um elemento no html
window.document.body.innerHTML +=  '<h1> Brasil x Argentina </h1>'

//exibndo um alerta 
window.alert('Olá mundo')

//Exibindo uma tela entrada de dados
var continuar = window.prompt('Voce deseja continuar ? ')
window.alert(continuar)

//exibindo uma tela de confirmacao
continuar = window.confirm('Voce deseja continuar ? ')
window.alert(continuar)

