//var e let

//Declarando var
var nome ='Hello World'
console.log(texto)

//Declarando let
let nome='Estefani'
console.log('Nome:', nome)

//Atribuindo um novo valor - let
nome ='Guilherme'
console.log('Nome:', nome)

////Atribuindo um novo valor - var
texto = 'Olá, mundo'
console.log(texto)

//Constantes - const
const valorPi = 3.14
console.log ('O valor de Pi é igual a ', valorPi)


