//operadores aritmeticos 
let n1 = 4
let n2 = 2

//operador soma
let soma= n1+ n2
console.log (soma)

//operador subtracao
let subtracao = n1 - n2
console.log(subtracao)

//operador multiplicacao
let multiplicacao = n1 * n2
console.log(multiplicacao)

//operador divisao ]
let divisao = n1 /n2
console.log(divisao)

//operador modulo 
let modulo = n1 % n2
console.log (modulo); 

//operador de potencia
let potencia = Math.pow(n1,n2)
console.log (potencia)

//operador raiz quadrada
let RaizQuadrada = Math.sqrt(n1)
console.log (RaizQaudrada);
