let n1 = 10
let n2 = 5
let n3 = 7

let media = (n1 + n2 + n3) / 3

if (media >= 5 ){
    console.log("Aprovado");
}
else if (media >= 5 ){
    console.log("Recuperação");

}
else {
    console.log("Reprovado");
}
